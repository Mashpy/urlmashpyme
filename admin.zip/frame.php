<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<html>
<head>
<title>Frame - PHPurl</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
body { margin : auto; height:100%; }
iframe { margin : auto; overflow: auto; }
#none { margin : auto; }

</style>
</head>


<body>


<div id="none">
To Enable Frame, go to config.php and change to 1.
<br /><br />
</div>

<div id="none1">

</body>
</html>