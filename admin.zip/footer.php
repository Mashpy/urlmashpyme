      <div class="navbar-inner navbar-fixed-bottom">
	  <p style="text-align:center; padding-top:10px"><a href="http://www.Mashpy.me"><b>Developed By MashpySays</b></a><p>
</div>
</body>
</html>
