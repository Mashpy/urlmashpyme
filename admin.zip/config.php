<?php

// Script Location:

$root = 'url.mashpy.me/';
$rooturl = 'http://url.mashpy.me/';
$destination = 'http://url.mashpy.me/go.php?id=';

// Open Link In Frame 1 Enable:

$frame = '0';

// Database Information:

$localhost ='localhost';
$username ='mashpy_url';
$password ='mashpy1234';
$database ='mashpy_url';

// Admin Username And Password:

$adminuser ='mashpy';
$adminpass ='mashpysays';

// Dont Edit Below:

$table = 'url';

$link = mysql_connect("$localhost", "$username", "$password")or die("Could not connect");
$db = mysql_select_db("$database", $link)or die("Could not select database");

?>